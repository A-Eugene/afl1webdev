<?php

class BookModel {
  public $id;
  public $author;       
  public $title;           
  public $publication_year;
  public $page_count;      
  public $isbn_number;     
  public $summary_text;
}

?>