<?php

class AuthorModel {
  public $id;
  public $full_name;
  public $birth_date;
  public $biography_summary;
}

?>