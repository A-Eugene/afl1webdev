<?php
# Redirect to /pengeluaran.php
header("Location: /books.php");
?>