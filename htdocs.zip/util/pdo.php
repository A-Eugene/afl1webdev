<?php

$pdo = new PDO('mysql:host=development.aeugene.top;dbname=afl1webdev', 'afl1webdev', 'afl1webdev123!');

?>